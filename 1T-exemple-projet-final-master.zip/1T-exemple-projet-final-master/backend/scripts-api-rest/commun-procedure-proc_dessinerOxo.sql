CREATE PROCEDURE "DBA"."proc_dessinerOxo"()
BEGIN

    DELETE from pixels;

INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5443,'#FFFFFF','original','no','2019-05-03 12:12:55.114');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5444,'#c0c0c0','oxo','pass','2019-05-03 12:13:19.419');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5445,'#FFFFFF','original','no','2019-05-03 12:12:55.114');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5446,'#c0c0c0','oxo','pass','2019-05-03 12:13:23.502');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5447,'#FFFFFF','original','no','2019-05-03 12:12:55.114');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5448,'#c0c0c0','oxo','pass','2019-05-03 12:13:25.026');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5449,'#c0c0c0','oxo','pass','2019-05-03 12:13:19.953');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5450,'#c0c0c0','oxo','pass','2019-05-03 12:13:25.607');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5451,'#c0c0c0','oxo','pass','2019-05-03 12:13:23.050');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5452,'#c0c0c0','oxo','pass','2019-05-03 12:13:26.148');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5453,'#FFFFFF','original','no','2019-05-03 12:12:55.115');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5454,'#c0c0c0','oxo','pass','2019-05-03 12:13:20.334');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5455,'#FFFFFF','original','no','2019-05-03 12:12:55.116');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5456,'#c0c0c0','oxo','pass','2019-05-03 12:13:22.479');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5457,'#FFFFFF','original','no','2019-05-03 12:12:55.116');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5458,'#c0c0c0','oxo','pass','2019-05-03 12:13:27.803');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5459,'#c0c0c0','oxo','pass','2019-05-03 12:13:20.778');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5460,'#c0c0c0','oxo','pass','2019-05-03 12:13:27.383');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5461,'#c0c0c0','oxo','pass','2019-05-03 12:13:22.047');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5462,'#c0c0c0','oxo','pass','2019-05-03 12:13:26.890');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5463,'#FFFFFF','original','no','2019-05-03 12:12:55.117');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5464,'#c0c0c0','oxo','pass','2019-05-03 12:13:21.144');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5465,'#FFFFFF','original','no','2019-05-03 12:12:55.117');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5466,'#c0c0c0','oxo','pass','2019-05-03 12:13:21.645');
INSERT INTO "DBA"."pixels" ("id","couleur","utilisateur","codeSecret","update_moment") VALUES(5467,'#FFFFFF','original','no','2019-05-03 12:12:55.117')
END;
