# 1T-exemple-projet-final
Exemple de la structure attendue pour le projet de fin d'année.

Attention, ce projet ne répond pas exactement aux critères qui vous sont demandés.
Par exemple : ici il n'y a qu'une seule table, il n'a pas de formulaire, pas de join et group by, ...

# Présentation de l'équipe
Indiquez les membres de votre équipe


# Description du projet
Vous devez expliquer textuellement et clairement ce qu'est votre projet, à quoi il sert, ce qu'il peut faire.

# Détail api rest
Pour chaque webservice, vous devez indiquer le endpoint, les paramètre et le format de réponse.
Indiquez aussi qui en est l'auteur. (Cela peut être "commun", mais il faut au  moins 1 webservice complet personnel par membre du groupe.)




